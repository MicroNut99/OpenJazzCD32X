/**
 * @file credits32x.h
 * PORT32X (J11): credits screen + CD player (see credits32x.cpp)
 */
#ifndef _CREDITS32X_H
#define _CREDITS32X_H
#include "OpenJazz.h"
int runCredits32X ();
#endif
